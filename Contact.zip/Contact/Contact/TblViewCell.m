//
//  tblViewCell.m
//  Contact
//
//  Created by multicoreViral on 3/29/16.
//  Copyright © 2016 multicore. All rights reserved.
//

#import "TblViewCell.h"

@implementation TblViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
